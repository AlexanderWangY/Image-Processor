#pragma once

struct Pixel {
  unsigned char blue;
  unsigned char green;
  unsigned char red;
};

struct NormalizedPixel {
  float blue;
  float green;
  float red;
};
